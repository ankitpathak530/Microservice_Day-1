package com.contact.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Contact {

	private Long cId;
	private String email;
	private String contactName;
	private Long userId;
	
	
	
}
