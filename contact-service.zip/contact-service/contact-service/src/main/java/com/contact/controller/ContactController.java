package com.contact.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.contact.exception.ContactException;
import com.contact.model.Contact;
import com.contact.service.ContactService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/contact")
@AllArgsConstructor
public class ContactController {

	
	private ContactService contactService;
	private static Logger LOGGER = LoggerFactory.getLogger(ContactController.class);
	private Environment environment;
	
	
	@GetMapping("/{id}")
	public Contact getContact(@PathVariable("id") Long id) throws ContactException {
		LOGGER.info("ContactController getContact() method  called...");
		LOGGER.info("ContactController getContact() method completed.");
		return this.contactService.getContact(id);
		
	}
	
	
	@GetMapping("/user/{id}")
	public List<Contact> getUser(@PathVariable("id") Long userId) {
		LOGGER.info("ContactController getUser() method  called...");
		LOGGER.info("ContactController getUser() method completed");
		return this.contactService.getContactsOfUser(userId);
		
	}
	
	
	@GetMapping("/port")
	public String getPort() {
		LOGGER.info("ContactController getPort() method  called...");
		LOGGER.info("ContactController getPort() method completed");
		return this.environment.getProperty("local.server.port");
	}
	
}
