package com.contact.exception;

public class ContactException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContactException(String s){super(s);}
}
