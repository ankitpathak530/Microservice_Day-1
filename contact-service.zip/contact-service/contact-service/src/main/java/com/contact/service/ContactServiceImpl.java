package com.contact.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.contact.controller.ContactController;
import com.contact.exception.ContactException;
import com.contact.model.Contact;

@Service
public class ContactServiceImpl implements ContactService {

	
	private static Logger LOGGER = LoggerFactory.getLogger(ContactController.class);
	
	
	List<Contact> contactList = List.of(
			 new Contact(1L,"amit123@gmail.com","Amit",121l),
			 new Contact(2L,"sumit@gmail.com","sumit",121l),
			 new Contact(3L,"amirajuert123@gmail.com","raju",121l),
			 
			 new Contact(4L,"sona3@gmail.com","Sona",122L),
			 new Contact(5L,"monae3@gmail.com","mona",122L),
			 new Contact(6L,"tona23@gmail.com","rona",122L),
			 
			 new Contact(7L,"himanshu33@gmail.com","Himashu",123L)
			);
			
	
	
	@Override
	public Contact getContact(Long id) throws ContactException {
		LOGGER.info("ContactService getContact() method  called...");
		LOGGER.info("ContactService getContact() method completed.");
		return this.contactList.stream().filter(e->e.getCId() == id).findAny().get();
	}

	@Override
	public List<Contact> getContactsOfUser(long userId) {
		LOGGER.info("ContactService getContactsOfUser() method  called...");
		LOGGER.info("ContactService getContactsOfUser() method completed.");
		return this.contactList.stream().filter(e->e.getUserId() == userId).toList();
	}


}
