package com.contact.service;

import java.util.List;

import com.contact.exception.ContactException;
import com.contact.model.Contact;

public interface ContactService {

	public Contact getContact(Long id) throws ContactException;
	
	public List<Contact> getContactsOfUser(long userId);
}
