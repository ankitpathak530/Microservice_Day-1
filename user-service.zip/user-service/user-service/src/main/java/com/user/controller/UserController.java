package com.user.controller;

import java.util.List;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.user.entity.Contact;
import com.user.entity.User;
import com.user.exception.UserException;
import com.user.service.UserService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/user")
@AllArgsConstructor
public class UserController {

	private final String USER_SERVICE = "userService";
	private UserService userService;
	private RestTemplate restTemplate;
	private static Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	private Environment environment;

	
	
	@GetMapping("/{id}")
	@CircuitBreaker(name = USER_SERVICE, fallbackMethod = "orderFallback")
	public ResponseEntity<?> getUser(@PathVariable("id") Long id) throws UserException {
		LOGGER.info("UserController getUser() method call started...");
		
		User user = this.userService.getUser(id);
		String url = "http://localhost:9002/contact/user/" + user.getUserId();
		@SuppressWarnings("unchecked")//calling contact microservice to fetch contact details and seting to user object
		List<Contact> forObject = this.restTemplate.getForObject(url, List.class);
		user.setContacts(forObject);

		LOGGER.info("UserController getUser() method call completed.");
		return ResponseEntity.status(HttpStatus.SC_OK).body(user);
	}

	

	public ResponseEntity<?> orderFallback(Exception e) {

		LOGGER.warn("UserController Fallback method called...");
		LOGGER.warn("Contact microservice is down or slow response");
		LOGGER.warn("UserController Fallback method completed");
		return ResponseEntity.status(org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE)
				             .body("Sorry for inconveniance. Server is on maintainace !");
	}

	
	
	@GetMapping("/")
	public List<User> getUsers() {
		LOGGER.info("UserController getUsers() method called...");
		LOGGER.info("UserController getUsers() method completed.");
		return this.userService.getAllUser();
	}

	
	@GetMapping("/port")
	public ResponseEntity<String> getPort() {
		LOGGER.info("UserController getPort() method called...");
		LOGGER.info("UserController getPort() method completed.");
		return ResponseEntity.status(HttpStatus.SC_OK)
				              .body(this.environment.getProperty("local.server.port"));
	}

}
