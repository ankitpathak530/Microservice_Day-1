package com.user.service;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import com.user.entity.User;
import com.user.exception.UserException;


@Service
public class UserServiceImpl implements UserService {

	private Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	
	List<User> userList = List.of(
			new User(121L,"Ankit Pathak","8089898989"),
			new User(122L,"Aman Pathak","7089898989"),
			new User(123L,"Shivam","9029898989")
			);
			
	
	
	@Override
	public User getUser(Long id) throws UserException {
		LOGGER.info("UserService getUser() method called...");
		LOGGER.info("UserService getUser() method completed.");
		return this.userList
		            .stream().filter( e -> e.getUserId() == id).findAny()
		            .orElseThrow(()-> new UserException("User Not found with id "+id));
		             
	}



	@Override
	public List<User> getAllUser() {
		LOGGER.info("UserService getAllUser() method called...");
		LOGGER.info("UserService getAllUser() method completed.");
		return this.userList;
	}
	
	
	

}
