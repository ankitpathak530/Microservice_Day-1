package com.user.service;

import java.util.List;

import com.user.entity.User;
import com.user.exception.UserException;

public interface UserService {

	public User getUser(Long id) throws UserException;
	
	public List<User> getAllUser();
}
